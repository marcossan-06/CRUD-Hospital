DROP DATABASE IF EXISTS hospital;
CREATE DATABASE IF NOT EXISTS hospital ;
USE hospital;

-- Tabla: hospitales
CREATE TABLE hospitales (
                            id_hospital INT PRIMARY KEY,
                            nombre VARCHAR(100),
                            ciudad VARCHAR(100),
                            pais VARCHAR(100),
                            capacidad INT,
                            pagina_web VARCHAR(200)
);

-- Tabla: medicos
CREATE TABLE medicos (
                         id_medico INT PRIMARY KEY,
                         nombre VARCHAR(100),
                         especialidad VARCHAR(100),
                         id_hospital INT,
                         FOREIGN KEY (id_hospital) REFERENCES hospitales(id_hospital)
);

-- Tabla: pacientes
CREATE TABLE pacientes (
                           id_paciente INT PRIMARY KEY auto_increment,
                           nombre VARCHAR(100),
                           edad INT,
                           nacionalidad VARCHAR(100),
                           id_medico INT,
                           habitacion VARCHAR(10),
                           FOREIGN KEY (id_medico) REFERENCES medicos(id_medico)
);

-- Tabla: tratamientos
CREATE TABLE tratamientos (
                              id_tratamiento VARCHAR(10) PRIMARY KEY,
                              descripcion VARCHAR(200),
                              fecha_inicio DATE,
                              duracion_dias INT,
                              id_paciente INT,
                              FOREIGN KEY (id_paciente) REFERENCES pacientes(id_paciente)
);
