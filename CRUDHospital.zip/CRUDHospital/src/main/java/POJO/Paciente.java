package POJO;

import java.util.ArrayList;

public class Paciente {

    private int id_paciente;
    private String nombre;
    private int edad;
    private String nacionalidad;
    private int id_medico;
    private String habitacion;
    private ArrayList<Tratamiento> tratamientos;

    public Paciente(int id_paciente, String nombre, int edad, String nacionalidad, int id_medico, String habitacion, ArrayList<Tratamiento> tratamientos) {
        this.id_paciente = id_paciente;
        this.nombre = nombre;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
        this.id_medico = id_medico;
        this.habitacion = habitacion;
        this.tratamientos = tratamientos;
    }

    public Paciente(String nombre, int edad, String nacionalidad, int id_medico, String habitacion, ArrayList<Tratamiento> tratamientos) {
        this.nombre = nombre;
        this.edad = edad;
        this.nacionalidad = nacionalidad;
        this.id_medico = id_medico;
        this.habitacion = habitacion;
        this.tratamientos = tratamientos;
    }

    public Paciente() {
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public int getId_medico() {
        return id_medico;
    }

    public void setId_medico(int id_medico) {
        this.id_medico = id_medico;
    }

    public String getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(String habitacion) {
        this.habitacion = habitacion;
    }

    public ArrayList<Tratamiento> getTratamientos() {
        return tratamientos;
    }

    public void setTratamientos(ArrayList<Tratamiento> tratamientos) {
        this.tratamientos = tratamientos;
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "id_paciente='" + id_paciente + '\'' +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", nacionalidad='" + nacionalidad + '\'' +
                ", id_medico=" + id_medico +
                ", habitacion='" + habitacion + '\'' +
                ", tratamientos=" + tratamientos +
                '}';
    }
}
