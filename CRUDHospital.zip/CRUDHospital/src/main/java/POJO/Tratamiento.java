package POJO;

import java.time.LocalDate;

public class Tratamiento {
    private String id_tratamiento;
    private String descripcion;
    private String fecha_inicio;
    private int duracion_dias;
    private int id_paciente;

    public Tratamiento(String id_tratamiento, String descripcion, String fecha_inicio, int duracion_dias, int id_paciente) {
        this.id_tratamiento = id_tratamiento;
        this.descripcion = descripcion;
        this.fecha_inicio = fecha_inicio;
        this.duracion_dias = duracion_dias;
        this.id_paciente = id_paciente;
    }

    public Tratamiento() {
    }

    public Tratamiento(String id_tratamiento, String descripcion, String fecha_inicio, int duracion_dias) {
        this.id_tratamiento = id_tratamiento;
        this.descripcion = descripcion;
        this.fecha_inicio = fecha_inicio;
        this.duracion_dias = duracion_dias;
    }

    public String getId_tratamiento() {
        return id_tratamiento;
    }

    public void setId_tratamiento(String id_tratamiento) {
        this.id_tratamiento = id_tratamiento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public int getDuracion_dias() {
        return duracion_dias;
    }

    public void setDuracion_dias(int duracion_dias) {
        this.duracion_dias = duracion_dias;
    }

    public int getId_paciente() {
        return id_paciente;
    }

    public void setId_paciente(int id_paciente) {
        this.id_paciente = id_paciente;
    }

    @Override
    public String toString() {
        return "Tratamiento{" +
                "id_tratamiento='" + id_tratamiento + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", fecha_inicio='" + fecha_inicio + '\'' +
                ", duracion_dias=" + duracion_dias +
                ", id_paciente=" + id_paciente +
                '}';
    }
}