package POJO;

import java.util.ArrayList;

public class Hospital {
    private int id_hospital;
    private String nombre;
    private String ciudad;
    private String pais;
    private int capacidad;
    private String pagina_web;

    public Hospital(int id_hospital, String nombre, String ciudad, String pais, int capacidad, String pagina_web) {
        this.id_hospital = id_hospital;
        this.nombre = nombre;
        this.ciudad = ciudad;
        this.pais = pais;
        this.capacidad = capacidad;
        this.pagina_web = pagina_web;
    }

    public Hospital() {

    }

    public int getId_hospital() {
        return id_hospital;
    }

    public void setId_hospital(int id_hospital) {
        this.id_hospital = id_hospital;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getPagina_web() {
        return pagina_web;
    }

    public void setPagina_web(String pagina_web) {
        this.pagina_web = pagina_web;
    }



    @Override
    public String toString() {
        return "Hospital{" +
                "id_hospital=" + id_hospital +
                ", nombre='" + nombre + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", pais='" + pais + '\'' +
                ", capacidad='" + capacidad + '\'' +
                ", pagina_web='" + pagina_web + '\'' +
                '}';
    }
}
