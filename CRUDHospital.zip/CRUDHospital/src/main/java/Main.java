import DAO.HospitalDAOImpl;

import DAO.MedicoDAOImpl;
import DAO.PacienteDAOImpl;
import POJO.Hospital;
import POJO.Medico;
import POJO.Paciente;
import POJO.Tratamiento;
import jsonParser.HospitalData;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static Tratamiento solicitarTratamiento(Scanner sc, int id_paciente) {
        int duracion_dias;
        String id_tratamiento, descripcion, fecha_inicio;
        System.out.println("Introduce el ID del tratamiento: ");
        id_tratamiento = sc.nextLine();
        System.out.println("Introduce su descripción: ");
        descripcion = sc.nextLine();
        System.out.println("Introduce su fecha de inicio (YYYY-MM-DD): ");
        fecha_inicio = sc.nextLine();
        System.out.println("Introduce los días que durará el tratamiento: ");
        duracion_dias = sc.nextInt();
        sc.skip("\n");
        return new Tratamiento(id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_paciente);
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // INCIAR LA BASE DE DATOS CON VALORES PREDETERMINADOS
        HospitalData hospitalData = new HospitalData();
        hospitalData.parseJson(hospitalData.getTextoJson());

        boolean modoSeguro = true;

        String tabla;
         do {
             System.out.println("¿En que tabla deseas operar? (1-5/S)");
             System.out.println("1. Hospitales.");
             System.out.println("2. Médicos.");
             System.out.println("3. Pacientes.");
             System.out.println("4. Mostrar registros.");
             if (modoSeguro) {
                 System.out.println("5. Desactivar modo seguro.");
             } else {
                 System.out.println("5. Activar modo seguro.");
             }
             System.out.println("S. Salir.");
            tabla = sc.nextLine().toUpperCase();
             String operacion;
             String respuesta;
            switch (tabla) {
                case "1":
                    do {
                        HospitalDAOImpl hospitalDAOImpl = new HospitalDAOImpl();
                        System.out.println("Tabla Hospitales seleccionada. ¿Qué operación desea realizar? (1-6/S)");
                        System.out.println("1. Buscar hospital por ID");
                        System.out.println("2. Buscar hospitales por ciudad");
                        System.out.println("3. Mostrar todos los hospitales");
                        System.out.println("4. Insertar hospital");
                        System.out.println("5. Actualizar hospital");
                        System.out.println("6. Eliminar hospital");
                        System.out.println("S. Volver atrás.");
                        operacion = sc.nextLine().toUpperCase();

                        int id_hospital, capacidad;
                        String nombre, ciudad, pais, pagina_web;

                        switch (operacion) {
                            case "1":
                                System.out.println("Introduce el ID del hospital: ");
                                id_hospital = sc.nextInt();
                                sc.skip("\n");
                                System.out.printf("Hospital con ID %d:\n", id_hospital);
                                System.out.println(hospitalDAOImpl.buscarPorId(id_hospital));
                                System.out.println("~".repeat(40));
                                break;
                            case "2":
                                System.out.println("Introduce el nombre de la ciudad: ");
                                ciudad = sc.nextLine();
                                System.out.printf("Hospitales de %s:\n", ciudad);
                                hospitalDAOImpl.buscarPorCiudad(ciudad).forEach(System.out::println);
                                System.out.println("~".repeat(40));
                                break;
                            case "3":
                                System.out.println("Todos los hospitales: ");
                                hospitalDAOImpl.listarTodos().forEach(System.out::println);
                                System.out.println("~".repeat(40));
                                break;
                            case "4":
                                System.out.println("Introduce el ID del hospital: ");
                                id_hospital = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce el nombre del hospital: ");
                                nombre = sc.nextLine();
                                System.out.println("Introduce la ciudad del hospital: ");
                                ciudad = sc.nextLine();
                                System.out.println("Introduce el país del hospital: ");
                                pais = sc.nextLine();
                                System.out.println("Introduce la capacidad: ");
                                capacidad = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la web del hospital: ");
                                pagina_web = sc.nextLine();
                                hospitalDAOImpl.insertar(new Hospital(id_hospital, nombre, ciudad, pais, capacidad, pagina_web));
                                System.out.println("~".repeat(40));
                                break;
                            case "5":
                                System.out.println("Introduce el ID del hospital a actualizar: ");
                                id_hospital = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce el nuevo nombre del hospital: ");
                                nombre = sc.nextLine();
                                System.out.println("Introduce la nueva ciudad del hospital: ");
                                ciudad = sc.nextLine();
                                System.out.println("Introduce el nuevo país del hospital: ");
                                pais = sc.nextLine();
                                System.out.println("Introduce la nueva capacidad del hospital: ");
                                capacidad = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la nueva web del hospital: ");
                                pagina_web = sc.nextLine();
                                hospitalDAOImpl.actualizar(new Hospital(id_hospital, nombre, ciudad, pais, capacidad, pagina_web));
                                System.out.println("~".repeat(40));
                                break;
                            case "6":
                                System.out.println("Introduce el ID del hospital a eliminar: ");
                                id_hospital = sc.nextInt();
                                sc.skip("\n");
                                hospitalDAOImpl.eliminar(id_hospital, modoSeguro);
                                System.out.println("~".repeat(40));
                                break;
                            case "S":
                                System.out.println("Volviendo atrás...");
                                System.out.println("~".repeat(40));
                                break;
                            default:
                                System.out.println("Introduce un valor válido 1-6/S");
                                System.out.println("~".repeat(40));
                                break;
                        }
                    } while (!operacion.equalsIgnoreCase("S"));
                    break;
                case "2":

                    do {
                        MedicoDAOImpl medicoDAOImpl = new MedicoDAOImpl();
                        System.out.println("Tabla Médicos seleccionada. ¿Qué operación desea realizar? (1-6/S)");
                        System.out.println("1. Buscar paciente por ID");
                        System.out.println("2. Buscar paciente por especialidad");
                        System.out.println("3. Mostrar todos los médicos");
                        System.out.println("4. Insertar médico");
                        System.out.println("5. Actualizar médico");
                        System.out.println("6. Eliminar médico");
                        System.out.println("S. Volver atrás.");
                        operacion = sc.nextLine().toUpperCase();

                        int id_medico, id_hospital;
                        String nombre, especialidad;

                        switch (operacion) {
                            case "1":
                                System.out.println("Introduce el ID del médico: ");
                                id_medico = sc.nextInt();
                                sc.skip("\n");
                                System.out.printf("Médico con ID %d:\n", id_medico);
                                System.out.println(medicoDAOImpl.buscarPorId(id_medico));
                                System.out.println("~".repeat(40));
                                break;
                            case "2":
                                System.out.println("Introduce al especialidad: ");
                                especialidad = sc.nextLine();
                                System.out.printf("Médicos de %s:\n", especialidad);
                                medicoDAOImpl.buscarPorEspecialidad(especialidad).forEach(System.out::println);
                                System.out.println("~".repeat(40));
                                break;
                            case "3":
                                System.out.println("Todos los médicos: ");
                                medicoDAOImpl.listarTodos().forEach(System.out::println);
                                System.out.println("~".repeat(40));
                                break;
                            case "4":
                                System.out.println("Introduce el ID del nuevo médico: ");
                                id_medico = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce el nombre del nuevo médico: ");
                                nombre = sc.nextLine();
                                System.out.println("Introduce la especialidad del nuevo médico: ");
                                especialidad = sc.nextLine();
                                System.out.println("Introduce el ID hospital asignado al nuevo médico: ");
                                id_hospital = sc.nextInt();
                                sc.skip("\n");
                                medicoDAOImpl.insertar(new Medico(id_medico, nombre, especialidad, id_hospital));
                                System.out.println("~".repeat(40));
                                break;
                            case "5":
                                System.out.println("Introduce el ID del médico a actualizar: ");
                                id_medico = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce el nuevo nombre del médico: ");
                                nombre = sc.nextLine();
                                System.out.println("Introduce la nueva especialidad del médico: ");
                                especialidad = sc.nextLine();
                                System.out.println("Introduce el nuevo hospital asignado al médico: ");
                                id_hospital = sc.nextInt();
                                sc.skip("\n");

                                medicoDAOImpl.actualizar(new Medico(id_medico, nombre, especialidad, id_hospital));
                                System.out.println("~".repeat(40));
                                break;
                            case "6":
                                System.out.println("Introduce el ID del médico a eliminar: ");
                                id_medico = sc.nextInt();
                                sc.skip("\n");
                                medicoDAOImpl.eliminar(id_medico, modoSeguro);
                                System.out.println("~".repeat(40));
                                break;
                            case "S":
                                System.out.println("~".repeat(40));
                                break;
                        }

                    } while (!operacion.equalsIgnoreCase("S"));
                    break;
                case "3":
                    do {
                        PacienteDAOImpl pacienteDAOImpl = new PacienteDAOImpl();
                        System.out.println("Tabla Pacientes seleccionada. ¿Qué operación desea realizar? (1-7/S)");
                        System.out.println("1. Buscar paciente por ID");
                        System.out.println("2. Buscar paciente por nacionalidad");
                        System.out.println("3. Mostrar todos los pacientes");
                        System.out.println("4. Insertar paciente");
                        System.out.println("5. Actualizar paciente");
                        System.out.println("6. Actualizar habitación de un paciente.");
                        System.out.println("7. Eliminar paciente");
                        System.out.println("S. Volver atrás.");
                        operacion = sc.nextLine().toUpperCase();

                        int id_paciente = 0, edad, id_medico;
                        String nombre, nacionalidad, habitacion;
                        ArrayList<Tratamiento> tratamientos = new ArrayList<>();

                        switch (operacion) {
                            case "1":
                                System.out.println("Introduce el ID del paciente: ");
                                id_paciente = sc.nextInt();
                                sc.skip("\n");
                                System.out.printf("Paciente con ID %d:\n", id_paciente);
                                System.out.println(pacienteDAOImpl.buscarPorId(id_paciente));
                                System.out.println("~".repeat(40));
                                break;
                            case "2":
                                System.out.println("Introduce la nacionalidad del paciente: ");
                                nacionalidad = sc.nextLine();
                                pacienteDAOImpl.buscarPorNacionalidad(nacionalidad).forEach(System.out::println);
                                System.out.println("~".repeat(40));
                                break;
                            case "3":
                                System.out.println("Todos los pacientes: ");
                                pacienteDAOImpl.listarTodos().forEach(System.out::println);
                                System.out.println("~".repeat(40));
                                break;
                            case "4":
                                System.out.println("Introduce el nombre del paciente: ");
                                nombre = sc.nextLine();
                                System.out.println("Introduce la edad del paciente: ");
                                edad = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la nacionalidad del paciente: ");
                                nacionalidad = sc.nextLine();
                                System.out.println("Introduce el ID del médico del paciente: ");
                                id_medico = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la habitación del paciente: ");
                                habitacion = sc.nextLine();

                                do {
                                    System.out.println("Introduce 'Y' para añadir un nuevo tratamiento al paciente: ");
                                    respuesta = sc.nextLine();
                                    if (respuesta.equalsIgnoreCase("Y")) {
                                        tratamientos.add(solicitarTratamiento(sc, id_paciente));
                                    }
                                } while (respuesta.equalsIgnoreCase("Y"));

                                pacienteDAOImpl.insertar(new Paciente(nombre, edad, nacionalidad, id_medico, habitacion, tratamientos));
                                System.out.println("~".repeat(40));
                                break;
                            case "5":
                                System.out.println("Introduce el ID del paciente a actualizar: ");
                                id_paciente = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce el nombre nuevo: ");
                                nombre = sc.nextLine();
                                System.out.println("Introduce la edad nueva: ");
                                edad = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la nueva nacionalidad: ");
                                nacionalidad = sc.nextLine();
                                System.out.println("Introduce el nuevo médico asignado: ");
                                id_medico = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la nueva habitacion: ");
                                habitacion = sc.nextLine();
                                do {
                                    System.out.println("Introduce 'Y' para añadir un nuevo tratamiento al paciente: ");
                                    respuesta = sc.nextLine();
                                    if (respuesta.equalsIgnoreCase("Y")) {
                                        tratamientos.add(solicitarTratamiento(sc, id_paciente));
                                    }
                                } while (respuesta.equalsIgnoreCase("Y"));

                                pacienteDAOImpl.actualizar(new Paciente(id_paciente, nombre, edad, nacionalidad, id_medico, habitacion, tratamientos ));
                                System.out.println("~".repeat(40));
                                break;
                            case "6":
                                System.out.println("Introduce el id del paciente: ");
                                id_paciente = sc.nextInt();
                                sc.skip("\n");
                                System.out.println("Introduce la nueva habitación del paciente: ");
                                habitacion = sc.nextLine();
                                pacienteDAOImpl.actualizarHabitacion(id_paciente, habitacion);
                                System.out.println("~".repeat(40));
                                break;
                            case "7":
                                System.out.println("Introduce el ID del paciente a eliminar: ");
                                id_paciente = sc.nextInt();
                                sc.skip("\n");
                                pacienteDAOImpl.eliminar(id_paciente, modoSeguro);
                                System.out.println("~".repeat(40));
                                break;
                            case "S":
                                System.out.println("~".repeat(40));
                                break;
                            default:
                                System.out.println("Introduce un valor válido 1-7/S");
                                System.out.println("~".repeat(40));
                                break;
                        }
                    } while (!operacion.equalsIgnoreCase("S"));
                    break;
                case "4":
                    try (BufferedReader br = new BufferedReader(new FileReader("logs.txt"))) {
                        String linea;
                        while ((linea = br.readLine()) != null) {
                            System.out.println(linea);
                        }
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                case "5":
                    if (modoSeguro) {
                        modoSeguro = false;
                        System.out.println("Modo seguro desactivado. (Al borrar una entidad se borrará todo lo relacionado con esta)");
                    }
                    else {
                        modoSeguro = true;
                        System.out.println("Modo seguro activado. (NO podrás borrar una entidad NO vacía)");
                    }
                    System.out.println("~".repeat(40));
                    break;
                case "S":
                    System.out.println("Cerrando programa...");
                    break;
                default:
                    System.out.println("Introduce un valor válido 1-5/S");
                    break;
            }
        } while (!tabla.equalsIgnoreCase("S"));
    }
}
