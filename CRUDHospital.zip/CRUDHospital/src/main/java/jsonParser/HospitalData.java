package jsonParser;

import DAO.conexionDB;
import POJO.Hospital;
import POJO.Medico;
import POJO.Paciente;
import POJO.Tratamiento;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import javax.print.attribute.standard.MediaSize;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class HospitalData {
    private ArrayList<Hospital> hospitales = new ArrayList<>();
    private ArrayList<Medico> medicos = new ArrayList<>();
    private ArrayList<Paciente> pacientes = new ArrayList<>();
    private static final Gson gson = new Gson();
    private static Connection conn = null;
    private final String textoJson = leerJson("hospital.json");


    public String getTextoJson() {
        return textoJson;
    }

    private static String leerJson(String nombreFichero) {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreFichero))) {
            String linea;
            String texto = "";
            while ((linea = br.readLine()) != null) {
                texto += linea;
            }
            return texto;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void parseJson(String textoJson) {
        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
//            System.out.println("Auto-commit después de setAutoCommit(false): " + conn.getAutoCommit());
            JsonObject jsonObject = gson.fromJson(textoJson, JsonObject.class);

            JsonArray hospitalesArray = jsonObject.get("hospitales").getAsJsonArray();
            for (JsonElement hospitalElement : hospitalesArray) {
                JsonObject hospitalJson = hospitalElement.getAsJsonObject();
                String ins_hospital = "INSERT INTO hospitales (id_hospital, nombre, ciudad, pais, capacidad, pagina_web) VALUES (?, ?, ?, ?, ?, ?);";
                try (PreparedStatement pst = conn.prepareStatement(ins_hospital)) {
                    pst.setInt(1, hospitalJson.get("id_hospital").getAsInt());
                    pst.setString(2, hospitalJson.get("nombre").getAsString());
                    pst.setString(3, hospitalJson.get("ciudad").getAsString());
                    pst.setString(4, hospitalJson.get("pais").getAsString());
                    pst.setInt(5, hospitalJson.get("capacidad").getAsInt());
                    pst.setString(6, hospitalJson.get("pagina_web").getAsString());
                    pst.executeUpdate();

                    Hospital hospital = gson.fromJson(hospitalJson, Hospital.class);
                    hospitales.add(hospital);
                }
            }
            System.out.println("~".repeat(40));
            System.out.println("HOSPITALES INSERTADOS: ");
            hospitales.forEach(System.out::println);
            System.out.println("~".repeat(40));

            JsonArray medicosArray = jsonObject.get("medicos").getAsJsonArray();
            for (JsonElement medicoElement : medicosArray) {
                JsonObject medicoJson = medicoElement.getAsJsonObject();
                String ins_medico = "INSERT INTO medicos (id_medico, nombre, especialidad, id_hospital) VALUES (?, ?, ?, ?);";
                try (PreparedStatement pst = conn.prepareStatement(ins_medico)) {
                    pst.setInt(1, medicoJson.get("id_medico").getAsInt());
                    pst.setString(2, medicoJson.get("nombre").getAsString());
                    pst.setString(3, medicoJson.get("especialidad").getAsString());
                    pst.setInt(4, medicoJson.get("id_hospital").getAsInt());
                    pst.executeUpdate();

                    Medico medico = gson.fromJson(medicoJson, Medico.class);
                    medicos.add(medico);
                }
            }
            System.out.println("~".repeat(40));
            System.out.println("MEDICOS INSERTADOS: ");
            medicos.forEach(System.out::println);
            System.out.println("~".repeat(40));

            JsonArray pacientesArray = jsonObject.get("pacientes").getAsJsonArray();
            for (JsonElement pacienteElement : pacientesArray) {
                JsonObject pacienteJson = pacienteElement.getAsJsonObject();
                String ins_paciente = "INSERT INTO pacientes (nombre, edad, nacionalidad, id_medico, habitacion) VALUES (?, ?, ?, ?, ?)";
                int id_paciente = 0;
                Paciente paciente = gson.fromJson(pacienteJson, Paciente.class);

                try (PreparedStatement pstPaciente = conn.prepareStatement(ins_paciente, Statement.RETURN_GENERATED_KEYS)) {
                    pstPaciente.setString(1, pacienteJson.get("nombre").getAsString());
                    pstPaciente.setInt(2, pacienteJson.get("edad").getAsInt());
                    pstPaciente.setString(3, pacienteJson.get("nacionalidad").getAsString());
                    pstPaciente.setInt(4, pacienteJson.get("id_medico").getAsInt());
                    pstPaciente.setString(5, pacienteJson.get("habitacion").getAsString());
                    pstPaciente.executeUpdate();

                    try (ResultSet generatedKeys = pstPaciente.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            id_paciente = generatedKeys.getInt(1);
                            paciente.setId_paciente(id_paciente);
                        }
                    }
                }

                JsonArray tratamientosArray = pacienteJson.get("tratamientos").getAsJsonArray();
                ArrayList<Tratamiento> tratamientos = new ArrayList<>();
                for (JsonElement tratamientoElement : tratamientosArray) {
                    JsonObject tratamientoJson = tratamientoElement.getAsJsonObject();
                    String ins_tratamiento = "INSERT INTO tratamientos (id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_paciente) VALUES (?, ?, ?, ?, ?) ";
                    try (PreparedStatement pstTratamiento = conn.prepareStatement(ins_tratamiento)) {
                        pstTratamiento.setString(1, tratamientoJson.get("id_tratamiento").getAsString());
                        pstTratamiento.setString(2, tratamientoJson.get("descripcion").getAsString());

                        String fechaStr = tratamientoJson.get("fecha_inicio").getAsString();
                        LocalDate fechaLocalDate = LocalDate.parse(fechaStr, DateTimeFormatter.ISO_LOCAL_DATE);
                        Date fechaSQL = Date.valueOf(fechaLocalDate);

                        pstTratamiento.setDate(3, fechaSQL);
                        pstTratamiento.setInt(4, tratamientoJson.get("duracion_dias").getAsInt());
                        pstTratamiento.setInt(5, id_paciente);
                        pstTratamiento.executeUpdate();

                        Tratamiento tratamiento = gson.fromJson(tratamientoJson, Tratamiento.class);
                        tratamiento.setId_paciente(id_paciente);
                        tratamientos.add(tratamiento);
                    }
                }
                paciente.setTratamientos(tratamientos);
                pacientes.add(paciente);
            }
            System.out.println("~".repeat(40));
            System.out.println("PACIENTES INSERTADOS: ");
            pacientes.forEach(System.out::println);
            System.out.println("~".repeat(40));
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
