package DAO.Interfaces;

import java.util.ArrayList;

public interface GenericDAO<T> {
    void insertar(T t);
    T buscarPorId(int id);
    ArrayList<T> listarTodos();
    void actualizar(T t);
    void eliminar(int id, boolean modoSeguro);
    void eliminarTotal(int id);
}
