package DAO.Interfaces;

import POJO.Hospital;

import java.util.ArrayList;

public interface HospitalDAO extends GenericDAO<Hospital> {
    ArrayList<Hospital> buscarPorCiudad(String ciudad);

}

