package DAO.Interfaces;

import POJO.Hospital;
import POJO.Paciente;

import java.util.ArrayList;

public interface PacienteDAO extends GenericDAO<Paciente> {
    ArrayList<Paciente> buscarPorNacionalidad(String nacionalidad);
    void actualizarHabitacion(int idPaciente, String nuevaHabitacion);
}
