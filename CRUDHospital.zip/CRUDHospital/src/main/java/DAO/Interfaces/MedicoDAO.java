package DAO.Interfaces;

import POJO.Medico;

import java.util.ArrayList;

public interface MedicoDAO extends GenericDAO<Medico> {
    ArrayList<Medico> buscarPorEspecialidad(String especialidad);
}
