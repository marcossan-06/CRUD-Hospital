package DAO;

import DAO.Interfaces.MedicoDAO;
import POJO.Hospital;
import POJO.Medico;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MedicoDAOImpl implements MedicoDAO {

    private static Connection conn = null;
    private static final File logs = new File("logs.txt");

    @Override
    public Medico buscarPorId(int id) {
        Medico medico = null;

        try {
            conn = conexionDB.getConnection();
            String sqlBuscarID = "SELECT * FROM medicos WHERE id_medico = ?;";

            try (PreparedStatement pst = conn.prepareStatement(sqlBuscarID)) {
                pst.setInt(1, id);

                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int id_medico = rs.getInt("id_medico");
                        String nombre = rs.getString("nombre");
                        String especialidad = rs.getString("especialidad");
                        int id_hospital = rs.getInt("id_hospital");

                        medico = new Medico(id_medico, nombre, especialidad, id_hospital);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return medico;
    }

    @Override
    public ArrayList<Medico> buscarPorEspecialidad(String especialidad) {

        ArrayList<Medico> medicos = new ArrayList<>();

        try {
            conn = conexionDB.getConnection();
            String medicos_especialidad = "SELECT * FROM medicos WHERE especialidad = ?;";

            try (PreparedStatement pst = conn.prepareStatement(medicos_especialidad)) {
                pst.setString(1, especialidad);
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int id_medico = rs.getInt("id_medico");
                        String nombre = rs.getString("nombre");
                        int id_hospital = rs.getInt("id_hospital");
                        medicos.add(new Medico(id_medico, nombre, especialidad, id_hospital));
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return medicos;
    }

    @Override
    public ArrayList<Medico> listarTodos() {

        ArrayList<Medico> medicos = new ArrayList<>();

        try {
            conn = conexionDB.getConnection();
            String sql_getAll = "SELECT * FROM medicos;";
            try (PreparedStatement pst = conn.prepareStatement(sql_getAll)) {
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int id_medico = rs.getInt("id_medico");
                        String nombre = rs.getString("nombre");
                        String especialidad = rs.getString("especialidad");
                        int id_hospital = rs.getInt("id_hospital");
                        medicos.add(new Medico(id_medico, nombre, especialidad, id_hospital));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return medicos;
    }

    @Override
    public void insertar(Medico medico) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
            String ins_medico = "INSERT INTO medicos (id_medico, nombre, especialidad, id_hospital) VALUES (?, ?, ?, ?);";
            try (PreparedStatement pst = conn.prepareStatement(ins_medico)) {
                pst.setInt(1, medico.getId_medico());
                pst.setString(2, medico.getNombre());
                pst.setString(3, medico.getEspecialidad());
                pst.setInt(4, medico.getId_hospital());
                pst.executeUpdate();
            }
            conn.commit();
        } catch (Exception e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.out.println("ERROR de restricción de SQL, comprueba que no se han introducido entradas duplicadas o IDs inexistentes. Detalles --> " + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR de restricción de SQL, comprueba que no se han introducido entradas duplicadas o IDs inexistentes. Detalles --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
            else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

    }

    @Override
    public void actualizar(Medico medico) {
        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
            String act_medico = "UPDATE medicos SET nombre = ?, especialidad = ?, id_hospital = ? WHERE id_medico = ?;";
            try (PreparedStatement pst = conn.prepareStatement(act_medico)) {
                pst.setString(1, medico.getNombre());
                pst.setString(2, medico.getEspecialidad());
                pst.setInt(3, medico.getId_hospital());
                pst.setInt(4, medico.getId_medico());
                int filasAfectadas = pst.executeUpdate();
                if (filasAfectadas == 0) {
                    System.out.println("No se encuentra el médico con el ID introducido.");
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.out.println("ERROR de restricción de SQL, comprueba que no se han introducido IDs inexistentes. Detalles --> " + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR de restricción de SQL, comprueba que no se han introducido IDs inexistentes. Detalles --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            } else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

    }

    @Override
    public void eliminar(int id_medico, boolean modoSeguro) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);

            if (!modoSeguro) {
                PacienteDAOImpl pacienteDAOImpl = new PacienteDAOImpl();
                String sql_pacientes = "SELECT id_paciente FROM pacientes WHERE id_medico = ?;";
                try (PreparedStatement pstPacientes = conn.prepareStatement(sql_pacientes)) {
                    pstPacientes.setInt(1, id_medico);
                    try (ResultSet rs = pstPacientes.executeQuery()) {
                        while (rs.next()) {
                            pacienteDAOImpl.eliminar(rs.getInt("id_paciente"), false);
                        }
                    }
                }
            }

            String elim_medico = "DELETE FROM medicos WHERE id_medico = ?";

            try (PreparedStatement pst = conn.prepareStatement(elim_medico)) {
                pst.setInt(1, id_medico);
                int filasAfectadas = pst.executeUpdate();
                if (filasAfectadas == 0) {
                    System.out.println("No se encuentra el médico con el ID introducido.");
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.out.println("ERROR: Un médico no puede ser eliminado si tiene pacientes asignados --> " + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR: Un médico no puede ser eliminado si tiene pacientes asignados --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            } else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }


    }

    @Override
    public void eliminarTotal(int id_medico) {


    }
}
