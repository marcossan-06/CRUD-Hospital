package DAO;

import DAO.Interfaces.PacienteDAO;
import POJO.Paciente;
import POJO.Tratamiento;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

public class PacienteDAOImpl implements PacienteDAO {

    private static Connection conn = null;
    private static final File logs = new File("logs.txt");

    @Override
    public Paciente buscarPorId(int id) {

        Paciente paciente = new Paciente();

        try {
            conn = conexionDB.getConnection();
            String sqlPaciente = "SELECT * FROM pacientes WHERE id_paciente = ?;";
            String sqlTratamientos = "SELECT * FROM tratamientos WHERE id_paciente = ?;";

            try (PreparedStatement pstmPaciente = conn.prepareStatement(sqlPaciente)) {
                pstmPaciente.setInt(1, id);
                try (ResultSet rs = pstmPaciente.executeQuery()) {
                    while (rs.next()) {
                        ArrayList<Tratamiento> tratamientos = new ArrayList<>();
                        int id_paciente = rs.getInt("id_paciente");
                        String nombre = rs.getString("nombre");
                        int edad = rs.getInt("edad");
                        String nacionalidad = rs.getString("nacionalidad");
                        int id_medico = rs.getInt("id_medico");
                        String habitacion = rs.getString("habitacion");

                        try (PreparedStatement pstmTratamientos = conn.prepareStatement(sqlTratamientos)) {
                            pstmTratamientos.setInt(1, id_paciente);
                            try (ResultSet rsTratamientos = pstmTratamientos.executeQuery()) {
                                while (rsTratamientos.next()) {
                                    String id_tratamiento = rsTratamientos.getString("id_Tratamiento");
                                    String descripcion = rsTratamientos.getString("descripcion");
                                    String fecha_inicio = rsTratamientos.getString("fecha_inicio");
                                    int duracion_dias = rsTratamientos.getInt("duracion_dias");
                                    tratamientos.add(new Tratamiento(id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_paciente));
                                }
                            }
                        }
                        paciente = new Paciente(id_paciente, nombre, edad, nacionalidad, id_medico, habitacion, tratamientos);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
        return paciente;
    }

    @Override
    public ArrayList<Paciente> buscarPorNacionalidad(String nacionalidad) {

        ArrayList<Paciente> pacientes = new ArrayList<>();

        try {
            conn = conexionDB.getConnection();
            String sqlPacientesPorNacioinalidad = "SELECT * FROM pacientes WHERE nacionalidad = ?;";
            String sqlTratamientos = "SELECT * FROM tratamientos WHERE id_paciente = ?;";

            try (PreparedStatement pstPaciente = conn.prepareStatement(sqlPacientesPorNacioinalidad)) {
                pstPaciente.setString(1, nacionalidad);

                try (ResultSet rs = pstPaciente.executeQuery()) {
                    while (rs.next()) {
                        ArrayList<Tratamiento> tratamientos = new ArrayList<>();
                        int id_paciente = rs.getInt("id_paciente");
                        String nombre = rs.getString("nombre");
                        int edad = rs.getInt("edad");
                        String nacionalidadPaciente = rs.getString("nacionalidad");
                        int id_medico = rs.getInt("id_medico");
                        String habitacion = rs.getString("habitacion");

                        try (PreparedStatement pstTratamientos = conn.prepareStatement(sqlTratamientos)) {
                            pstTratamientos.setInt(1, id_paciente);
                            try (ResultSet rsTratamientos = pstTratamientos.executeQuery()) {
                                while (rsTratamientos.next()) {
                                    String id_tratamiento = rsTratamientos.getString("id_tratamiento");
                                    String descripcion = rsTratamientos.getString("descripcion");
                                    String fecha_inicio = rsTratamientos.getString("fecha_inicio");
                                    int duracion_dias = rsTratamientos.getInt("duracion_dias");
                                    int id_pacienteT = rsTratamientos.getInt("id_paciente");
                                    tratamientos.add(new Tratamiento(id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_pacienteT));
                                }
                            }
                        }
                        pacientes.add(new Paciente(id_paciente, nombre, edad, nacionalidadPaciente, id_medico, habitacion, tratamientos));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return pacientes;
    }


    @Override
    public ArrayList<Paciente> listarTodos() {
        ArrayList<Paciente> pacientes = new ArrayList<>();

        try {
            conn = conexionDB.getConnection();
            String sqlPacientes = "SELECT * FROM pacientes;";
            String sqlTratamientos = "SELECT * FROM tratamientos WHERE id_paciente = ?;";

            try (PreparedStatement pstPaciente = conn.prepareStatement(sqlPacientes)) {
                try (ResultSet rs = pstPaciente.executeQuery()) {
                    while (rs.next()) {
                        ArrayList<Tratamiento> tratamientos = new ArrayList<>();
                        int id_paciente = rs.getInt("id_paciente");
                        String nombre = rs.getString("nombre");
                        int edad = rs.getInt("edad");
                        String nacionalidad = rs.getString("nacionalidad");
                        int id_medico = rs.getInt("id_medico");
                        String habitacion = rs.getString("habitacion");
                        try (PreparedStatement pstTratamientos = conn.prepareStatement(sqlTratamientos)) {
                            pstTratamientos.setInt(1, id_paciente);
                            try (ResultSet rsTratamientos = pstTratamientos.executeQuery()) {
                                while (rsTratamientos.next()) {
                                    String id_tratamiento = rsTratamientos.getString("id_tratamiento");
                                    String descripcion = rsTratamientos.getString("descripcion");
                                    String fecha_inicio = rsTratamientos.getString("fecha_inicio");
                                    int duracion_dias = rsTratamientos.getInt("duracion_dias");
                                    tratamientos.add(new Tratamiento(id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_paciente));
                                }
                            }
                        }
                        pacientes.add(new Paciente(id_paciente, nombre, edad, nacionalidad, id_medico, habitacion, tratamientos));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return pacientes;
    }

    @Override
    public void insertar(Paciente paciente) {
        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
            String ins_paciente = "INSERT INTO pacientes (nombre, edad, nacionalidad, id_medico, habitacion) VALUES (?, ?, ?, ?, ?);";
            String ins_tratamientos = "INSERT INTO tratamientos (id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_paciente) VALUES (?, ?, ?, ?, ?);";
            int id_paciente = 0;

            try (PreparedStatement pstPaciente = conn.prepareStatement(ins_paciente, Statement.RETURN_GENERATED_KEYS)) {
                pstPaciente.setString(1, paciente.getNombre());
                pstPaciente.setInt(2, paciente.getEdad());
                pstPaciente.setString(3, paciente.getNacionalidad());
                pstPaciente.setInt(4, paciente.getId_medico());
                pstPaciente.setString(5, paciente.getHabitacion());
                pstPaciente.executeUpdate();

                try (ResultSet rs = pstPaciente.getGeneratedKeys()) {
                    while (rs.next()) {
                        id_paciente = rs.getInt(1);
                    }
                }
            }

            for (Tratamiento tratamiento : paciente.getTratamientos()) {
                try (PreparedStatement pstTratamientos = conn.prepareStatement(ins_tratamientos)) {
                    pstTratamientos.setString(1, tratamiento.getId_tratamiento());
                    pstTratamientos.setString(2, tratamiento.getDescripcion());
                    String fechaStr = tratamiento.getFecha_inicio();
                    LocalDate fechaLocalDate = LocalDate.parse(fechaStr, DateTimeFormatter.ISO_LOCAL_DATE);
                    java.sql.Date fechaSQL = java.sql.Date.valueOf(fechaLocalDate);
                    pstTratamientos.setDate(3, fechaSQL);
                    pstTratamientos.setInt(4, tratamiento.getDuracion_dias());
                    pstTratamientos.setInt(5, id_paciente);
                    pstTratamientos.executeUpdate();
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.out.println("ERROR: El medico asignado al paciente no existe -->" + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR: El medico asignado al paciente no existe --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            } else if (e instanceof DateTimeParseException) {
                System.out.println("ERROR: El formato de la fecha introducido es incorrecto -->" + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR: El formato de la fecha introducido es incorrecto --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            } else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void actualizar(Paciente paciente) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
            String act_paciente = "UPDATE pacientes SET nombre = ?, edad = ?, nacionalidad = ?, id_medico = ?, habitacion = ? WHERE id_paciente = ?;";
            String elim_tratamientos = "DELETE FROM tratamientos WHERE id_paciente = ?;";
            String ins_tratamientos = "INSERT INTO tratamientos (id_tratamiento, descripcion, fecha_inicio, duracion_dias, id_paciente) VALUES (?, ?, ?, ?, ?);";

            int filasAfectadas;

            try (PreparedStatement pstPaciente = conn.prepareStatement(act_paciente)) {
                pstPaciente.setString(1, paciente.getNombre());
                pstPaciente.setInt(2, paciente.getEdad());
                pstPaciente.setString(3, paciente.getNacionalidad());
                pstPaciente.setInt(4, paciente.getId_medico());
                pstPaciente.setString(5, paciente.getHabitacion());
                pstPaciente.setInt(6, paciente.getId_paciente());
                filasAfectadas = pstPaciente.executeUpdate();
                if (filasAfectadas == 0) {
                    System.out.println("No se ha encontrado el paciente con el ID introducido.");
                }
            }

            try (PreparedStatement pstTratamientos = conn.prepareStatement(elim_tratamientos)) {
                pstTratamientos.setInt(1, paciente.getId_paciente());
                pstTratamientos.executeUpdate();
            }

            for (Tratamiento tratamiento : paciente.getTratamientos()) {
                try (PreparedStatement pstTratamientos = conn.prepareStatement(ins_tratamientos)) {
                    pstTratamientos.setString(1, tratamiento.getId_tratamiento());
                    pstTratamientos.setString(2, tratamiento.getDescripcion());
                    String fechaStr = tratamiento.getFecha_inicio();
                    LocalDate fechaLocalDate = LocalDate.parse(fechaStr, DateTimeFormatter.ISO_LOCAL_DATE);
                    java.sql.Date fechaSQL = java.sql.Date.valueOf(fechaLocalDate);
                    pstTratamientos.setDate(3, fechaSQL);
                    pstTratamientos.setInt(4, tratamiento.getDuracion_dias());
                    pstTratamientos.setInt(5, tratamiento.getId_paciente());
                    pstTratamientos.executeUpdate();
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.out.println("ERROR: El medico asignado al paciente no existe -->" + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR: El medico asignado al paciente no existe --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            } else if (e instanceof DateTimeParseException) {
                System.out.println("ERROR: El formato de la fecha introducido es incorrecto -->" + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR: El formato de la fecha introducido es incorrecto --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            } else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    @Override
    public void actualizarHabitacion(int idPaciente, String nuevaHabitacion) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
            String act_Habitacion = "UPDATE pacientes SET habitacion = ? WHERE id_paciente = ?;";

            try (PreparedStatement pstHabitacion = conn.prepareStatement(act_Habitacion)) {
                pstHabitacion.setString(1, nuevaHabitacion);
                pstHabitacion.setInt(2, idPaciente);
                int filasAfectadas = pstHabitacion.executeUpdate();
                if (filasAfectadas == 0) {
                    System.out.println("no se encuentra el paciente con el ID introducido.");
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void eliminar(int id, boolean modoSeguro) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);

            String elim_tratamientos = "DELETE FROM tratamientos WHERE id_paciente = ?;";
            String elim_paciente = "DELETE FROM pacientes WHERE id_paciente = ?;";
            try (PreparedStatement pstTratamientos = conn.prepareStatement(elim_tratamientos)) {
                pstTratamientos.setInt(1, id);
                pstTratamientos.executeUpdate();
            }
            try (PreparedStatement pstPaciente = conn.prepareStatement(elim_paciente)) {
                pstPaciente.setInt(1, id);
                pstPaciente.executeUpdate();
            }

            conn.commit();
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    @Override
    public void eliminarTotal(int id) {

    }
}
