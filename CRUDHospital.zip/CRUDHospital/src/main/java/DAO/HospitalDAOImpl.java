package DAO;

import DAO.Interfaces.HospitalDAO;
import POJO.Hospital;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class HospitalDAOImpl implements HospitalDAO {

    private static Connection conn = null;
    private static final File logs = new File("logs.txt");

    @Override
    public Hospital buscarPorId(int id) {

        Hospital hospital = null;

        try {
            conn = conexionDB.getConnection();
            String sqlBuscarID = "SELECT * FROM hospitales WHERE id_hospital = ?;";

            try (PreparedStatement pst = conn.prepareStatement(sqlBuscarID)) {
                pst.setInt(1, id);

                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int id_hospital = rs.getInt("id_hospital");
                        String nombre = rs.getString("nombre");
                        String ciudad = rs.getString("ciudad");
                        String pais = rs.getString("pais");
                        int capacidad = rs.getInt("capacidad");
                        String pagina_web = rs.getString("pagina_web");

                        hospital = new Hospital(id_hospital, nombre, ciudad, pais, capacidad, pagina_web);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        return hospital;
    }

    @Override
    public ArrayList<Hospital> buscarPorCiudad(String ciudad) {

        ArrayList<Hospital> hospitales = new ArrayList<>();
        try {
            conn = conexionDB.getConnection();
            String sqlBuscarCiudad = "SELECT * FROM hospitales WHERE ciudad LIKE ?;";

            try (PreparedStatement pst = conn.prepareStatement(sqlBuscarCiudad)) {
                pst.setString(1, ciudad);

                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int id_hospital = rs.getInt("id_hospital");
                        String nombre = rs.getString("nombre");
                        String ciudadHospital = rs.getString("ciudad");
                        String pais = rs.getString("pais");
                        int capacidad = rs.getInt("capacidad");
                        String pagina_web = rs.getString("pagina_web");

                        Hospital hospital = new Hospital(id_hospital, nombre, ciudadHospital, pais, capacidad, pagina_web);
                        hospitales.add(hospital);
                    }
                }
            }
        } catch (Exception e) {
           e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e ) {
                    e.printStackTrace();
                }
            }
        }
        return hospitales;
    }

    @Override
    public ArrayList<Hospital> listarTodos() {

        ArrayList<Hospital> hospitales = new ArrayList<>();
        try {
            conn = conexionDB.getConnection();
            String sqlListarTodos = "SELECT * FROM hospitales;";

            try (PreparedStatement pst = conn.prepareStatement(sqlListarTodos)) {
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int id_hospital = rs.getInt("id_hospital");
                        String nombre = rs.getString("nombre");
                        String ciudad = rs.getString("ciudad");
                        String pais = rs.getString("pais");
                        int capacidad = rs.getInt("capacidad");
                        String pagina_web = rs.getString("pagina_web");
                        Hospital hospital = new Hospital(id_hospital, nombre, ciudad, pais, capacidad, pagina_web);
                        hospitales.add(hospital);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e ) {
                    e.printStackTrace();
                }
            }
        }
        return hospitales;
    }

    @Override
    public void insertar(Hospital hospital) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);

            String insHospital = "INSERT INTO hospitales (id_hospital, nombre, ciudad, pais, capacidad, pagina_web) VALUES (?,?,?,?,?,?);";

            try (PreparedStatement pst = conn.prepareStatement(insHospital)) {
                pst.setInt(1, hospital.getId_hospital());
                pst.setString(2, hospital.getNombre());
                pst.setString(3, hospital.getCiudad());
                pst.setString(4, hospital.getPais());
                pst.setInt(5, hospital.getCapacidad());
                pst.setString(6, hospital.getPagina_web());
                pst.executeUpdate();
            } catch (SQLIntegrityConstraintViolationException e) {
                System.out.println("Error al insertar el hospital --> " + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: Error al insertar el hospital --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }


    @Override
    public void actualizar(Hospital hospital) {

        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);
            String sqlActualizar = "UPDATE hospitales SET nombre = ?, ciudad = ?, pais = ?, capacidad = ?, pagina_web = ? WHERE id_hospital = ?;";

            try (PreparedStatement pst = conn.prepareStatement(sqlActualizar)) {
                pst.setString(1, hospital.getNombre());
                pst.setString(2, hospital.getCiudad());
                pst.setString(3, hospital.getPais());
                pst.setInt(4, hospital.getCapacidad());
                pst.setString(5, hospital.getPagina_web());
                pst.setInt(6, hospital.getId_hospital());
                int filasAfectadas = pst.executeUpdate();
                if (filasAfectadas == 0) {
                    System.out.println("No se encuentra el hospital con el ID introducido.");
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    @Override
    public void eliminar(int id_hospital, boolean modoSeguro) {
        try {
            conn = conexionDB.getConnection();
            conn.setAutoCommit(false);

            if (!modoSeguro) {
                MedicoDAOImpl medicoDAOImpl = new MedicoDAOImpl();
                String sql_medicos = "SELECT id_medico FROM medicos WHERE id_hospital = ?;";
                try (PreparedStatement pst = conn.prepareStatement(sql_medicos)) {
                    pst.setInt(1, id_hospital);
                    try (ResultSet rs = pst.executeQuery()) {
                        while (rs.next()) {
                            medicoDAOImpl.eliminar(rs.getInt("id_medico"), false);
                        }
                    }
                }
            }

            String sqlElimHospital = "DELETE FROM hospitales WHERE id_hospital = ?;";
            try (PreparedStatement pst = conn.prepareStatement(sqlElimHospital)) {
                pst.setInt(1, id_hospital);
                int filasAfectadas = pst.executeUpdate();
                if (filasAfectadas == 0) {
                    System.out.println("No se encuentra el hospital con el ID introducido.");
                }
            }
            conn.commit();
        } catch (Exception e) {
            if (e instanceof SQLIntegrityConstraintViolationException) {
                System.out.println("ERROR: El hospital debe estar vacío antes de ser eliminado --> " + e.getMessage());
                try (PrintWriter pw = new PrintWriter(new FileWriter(logs, true))) {
                    pw.printf("[%s %.8s]: ERROR: El hospital debe estar vacío antes de ser eliminado --> %s\n", LocalDate.now(), LocalTime.now(), e.getMessage());
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
            else {
                e.printStackTrace();
            }
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

    }

    @Override
    public void eliminarTotal(int id_hospital) {

    }
}
